import { useState, useEffect } from 'react';
import { Trash2, AlertCircle, DollarSign, Calendar, TrendingDown, LinkIcon } from 'lucide-react';
import { supabase, type Subscription } from '../lib/supabase';

export default function SubscriptionAssassin() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [isConnecting, setIsConnecting] = useState(false);

  useEffect(() => {
    loadSubscriptions();
  }, []);

  const loadSubscriptions = async () => {
    try {
      const { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .order('amount', { ascending: false });

      if (error) throw error;
      setSubscriptions(data || []);
    } catch (error) {
      console.error('Error loading subscriptions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConnectAccount = async () => {
    setIsConnecting(true);

    const mockSubscriptions = [
      { name: 'Netflix Premium', amount: 19.99, category: 'Streaming', billing_cycle: 'monthly', next_billing_date: '2026-02-01', last_used: '2026-01-15T10:30:00Z' },
      { name: 'Spotify Family', amount: 16.99, category: 'Music', billing_cycle: 'monthly', next_billing_date: '2026-02-05', last_used: '2026-01-17T08:15:00Z' },
      { name: 'Adobe Creative Cloud', amount: 54.99, category: 'Software', billing_cycle: 'monthly', next_billing_date: '2026-01-25', last_used: '2025-12-20T14:00:00Z' },
      { name: 'ChatGPT Plus', amount: 20.00, category: 'AI Tools', billing_cycle: 'monthly', next_billing_date: '2026-02-10', last_used: '2026-01-18T09:00:00Z' },
      { name: 'Gym Membership', amount: 45.00, category: 'Fitness', billing_cycle: 'monthly', next_billing_date: '2026-02-01', last_used: '2025-11-05T18:30:00Z' }
    ];

    try {
      for (const sub of mockSubscriptions) {
        await supabase.from('subscriptions').insert({
          user_id: null,
          name: sub.name,
          amount: sub.amount,
          category: sub.category,
          billing_cycle: sub.billing_cycle,
          next_billing_date: sub.next_billing_date,
          last_used: sub.last_used,
          status: 'active'
        });
      }

      await loadSubscriptions();
    } catch (error) {
      console.error('Error adding subscriptions:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleKillSubscription = async (id: string) => {
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({ status: 'cancelled' })
        .eq('id', id);

      if (error) throw error;
      await loadSubscriptions();
    } catch (error) {
      console.error('Error cancelling subscription:', error);
    }
  };

  const getWasteWarningLevel = (lastUsed: string | null) => {
    if (!lastUsed) return 'unknown';
    const daysSinceUsed = Math.floor((new Date().getTime() - new Date(lastUsed).getTime()) / (1000 * 60 * 60 * 24));
    if (daysSinceUsed > 60) return 'high';
    if (daysSinceUsed > 30) return 'medium';
    return 'low';
  };

  const activeSubscriptions = subscriptions.filter(sub => sub.status === 'active');
  const totalMonthlyWaste = activeSubscriptions.reduce((sum, sub) => sum + Number(sub.amount), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Subscription Assassin</h2>
          <p className="text-gray-400">AI-powered subscription waste detection</p>
        </div>

        {activeSubscriptions.length === 0 && (
          <button
            onClick={handleConnectAccount}
            disabled={isConnecting}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold px-6 py-3 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/20"
          >
            <LinkIcon className="w-5 h-5" />
            {isConnecting ? 'Scanning...' : 'Connect Account'}
          </button>
        )}
      </div>

      {activeSubscriptions.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-gray-950 to-gray-900 border border-gray-800/50 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-red-500/10 rounded-lg flex items-center justify-center border border-red-500/20">
                <DollarSign className="w-5 h-5 text-red-400" />
              </div>
              <span className="text-gray-400 text-sm font-medium">Monthly Burn</span>
            </div>
            <div className="text-3xl font-bold text-white">${totalMonthlyWaste.toFixed(2)}</div>
          </div>

          <div className="bg-gradient-to-br from-gray-950 to-gray-900 border border-gray-800/50 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center border border-blue-500/20">
                <AlertCircle className="w-5 h-5 text-blue-400" />
              </div>
              <span className="text-gray-400 text-sm font-medium">Active Subscriptions</span>
            </div>
            <div className="text-3xl font-bold text-white">{activeSubscriptions.length}</div>
          </div>

          <div className="bg-gradient-to-br from-gray-950 to-gray-900 border border-gray-800/50 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-yellow-500/10 rounded-lg flex items-center justify-center border border-yellow-500/20">
                <TrendingDown className="w-5 h-5 text-yellow-400" />
              </div>
              <span className="text-gray-400 text-sm font-medium">Potential Savings</span>
            </div>
            <div className="text-3xl font-bold text-white">
              ${(totalMonthlyWaste * 0.4).toFixed(2)}
            </div>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-br from-gray-950 to-gray-900 border border-gray-800/50 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-800/50">
          <h3 className="text-lg font-semibold text-white">Detected Subscriptions</h3>
        </div>

        <div className="p-6">
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-gray-400">Scanning for subscriptions...</p>
            </div>
          ) : activeSubscriptions.length === 0 ? (
            <div className="text-center py-12">
              <AlertCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 mb-2">No subscriptions detected</p>
              <p className="text-gray-600 text-sm">Connect your account to start scanning</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activeSubscriptions.map((subscription) => {
                const wasteLevel = getWasteWarningLevel(subscription.last_used);
                const wasteColors = {
                  high: 'border-red-500/30 bg-red-500/5',
                  medium: 'border-yellow-500/30 bg-yellow-500/5',
                  low: 'border-green-500/30 bg-green-500/5',
                  unknown: 'border-gray-500/30 bg-gray-500/5'
                };

                return (
                  <div
                    key={subscription.id}
                    className={`border ${wasteColors[wasteLevel]} rounded-lg p-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors duration-200`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-white font-semibold text-lg">{subscription.name}</h4>
                        {wasteLevel === 'high' && (
                          <span className="bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-semibold px-2 py-1 rounded-full uppercase">
                            High Waste
                          </span>
                        )}
                        {wasteLevel === 'medium' && (
                          <span className="bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 text-xs font-semibold px-2 py-1 rounded-full uppercase">
                            Low Usage
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-6 text-sm">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-gray-500" />
                          <span className="text-gray-400">${Number(subscription.amount).toFixed(2)}</span>
                          <span className="text-gray-600">/ {subscription.billing_cycle}</span>
                        </div>

                        {subscription.next_billing_date && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-gray-500" />
                            <span className="text-gray-400">
                              Next: {new Date(subscription.next_billing_date).toLocaleDateString()}
                            </span>
                          </div>
                        )}

                        {subscription.category && (
                          <span className="bg-gray-800/50 text-gray-400 px-2 py-1 rounded text-xs">
                            {subscription.category}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => handleKillSubscription(subscription.id)}
                      className="flex items-center gap-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-semibold px-4 py-2 rounded-lg transition-all duration-200 ml-4"
                    >
                      <Trash2 className="w-4 h-4" />
                      Kill
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { Shield, Sword, Activity } from 'lucide-react';
import SavingsTicker from './SavingsTicker';
import AgentStatusCard from './AgentStatusCard';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <SavingsTicker />

        <div>
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            Agent Status
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <AgentStatusCard
              title="Subscription Assassin"
              status="scanning"
              icon={Shield}
              lastScan="2 min ago"
              itemsFound={5}
              color="blue"
            />

            <AgentStatusCard
              title="Bill Auditor"
              status="idle"
              icon={Shield}
              lastScan="1 hour ago"
              itemsFound={0}
              color="green"
            />

            <AgentStatusCard
              title="Amazon Sniper"
              status="scanning"
              icon={Sword}
              lastScan="5 min ago"
              itemsFound={12}
              color="purple"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

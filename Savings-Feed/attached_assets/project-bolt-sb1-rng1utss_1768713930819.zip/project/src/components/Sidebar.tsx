import { Shield, Crosshair, Pickaxe, Zap } from 'lucide-react';
import { useState } from 'react';

type SectorType = 'defense' | 'offense' | 'mining';

const sectors = [
  {
    id: 'defense' as SectorType,
    name: 'DEFENSE',
    icon: Shield,
    modules: ['Subscription Assassin', 'Bill Auditor']
  },
  {
    id: 'offense' as SectorType,
    name: 'OFFENSE',
    icon: Crosshair,
    modules: ['Amazon Sniper', 'Flight Scalper']
  },
  {
    id: 'mining' as SectorType,
    name: 'MINING',
    icon: Pickaxe,
    modules: ['Passive Data Income']
  }
];

export default function Sidebar() {
  const [activeSector, setActiveSector] = useState<SectorType>('defense');
  const [activeModule, setActiveModule] = useState('Subscription Assassin');

  return (
    <div className="w-72 bg-gradient-to-b from-gray-950 to-black border-r border-gray-800/50 flex flex-col">
      <div className="p-6 border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
            <Zap className="w-6 h-6 text-black" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">Life Lever</h1>
            <p className="text-xs text-blue-400 font-medium">AI OPTIMIZATION</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-2">
        {sectors.map((sector) => {
          const Icon = sector.icon;
          const isActive = activeSector === sector.id;

          return (
            <div key={sector.id} className="space-y-1">
              <button
                onClick={() => setActiveSector(sector.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-500/10 border border-blue-500/30 text-blue-400'
                    : 'text-gray-400 hover:bg-gray-800/30 hover:text-gray-300'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-semibold text-sm tracking-wide">{sector.name}</span>
              </button>

              {isActive && (
                <div className="ml-4 pl-4 border-l border-blue-500/20 space-y-1">
                  {sector.modules.map((module) => {
                    const isModuleActive = activeModule === module;
                    return (
                      <button
                        key={module}
                        onClick={() => setActiveModule(module)}
                        className={`w-full text-left px-3 py-2 rounded text-sm transition-all duration-200 ${
                          isModuleActive
                            ? 'text-blue-400 bg-blue-500/5 font-medium'
                            : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/20'
                        }`}
                      >
                        {module}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="p-4 border-t border-gray-800/50">
        <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-lg p-4 border border-gray-800/50">
          <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">System Status</div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-300 font-medium">All Agents Active</span>
          </div>
        </div>
      </div>
    </div>
  );
}

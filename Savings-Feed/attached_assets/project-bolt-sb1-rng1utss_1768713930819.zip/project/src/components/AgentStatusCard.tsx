import { LucideIcon } from 'lucide-react';

interface AgentStatusCardProps {
  title: string;
  status: 'scanning' | 'idle' | 'found';
  icon: LucideIcon;
  lastScan: string;
  itemsFound?: number;
  color: 'blue' | 'green' | 'purple';
}

const colorClasses = {
  blue: {
    bg: 'from-blue-500/10 to-blue-600/5',
    border: 'border-blue-500/30',
    icon: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
    statusBg: 'bg-blue-500/10',
    statusBorder: 'border-blue-500/20',
    statusText: 'text-blue-400'
  },
  green: {
    bg: 'from-green-500/10 to-green-600/5',
    border: 'border-green-500/30',
    icon: 'bg-green-500/10 border-green-500/20 text-green-400',
    statusBg: 'bg-green-500/10',
    statusBorder: 'border-green-500/20',
    statusText: 'text-green-400'
  },
  purple: {
    bg: 'from-purple-500/10 to-purple-600/5',
    border: 'border-purple-500/30',
    icon: 'bg-purple-500/10 border-purple-500/20 text-purple-400',
    statusBg: 'bg-purple-500/10',
    statusBorder: 'border-purple-500/20',
    statusText: 'text-purple-400'
  }
};

const statusLabels = {
  scanning: 'Active Scan',
  idle: 'Idle',
  found: 'Items Found'
};

export default function AgentStatusCard({
  title,
  status,
  icon: Icon,
  lastScan,
  itemsFound = 0,
  color
}: AgentStatusCardProps) {
  const colors = colorClasses[color];

  return (
    <div className={`bg-gradient-to-br ${colors.bg} border ${colors.border} rounded-xl p-5 backdrop-blur-sm relative overflow-hidden group hover:scale-[1.02] transition-transform duration-200`}>
      <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className={`w-12 h-12 ${colors.icon} rounded-lg flex items-center justify-center border`}>
            <Icon className="w-6 h-6" />
          </div>

          <div className={`${colors.statusBg} px-3 py-1 rounded-full border ${colors.statusBorder} flex items-center gap-2`}>
            {status === 'scanning' && (
              <div className={`w-2 h-2 ${colors.statusText.replace('text-', 'bg-')} rounded-full animate-pulse`}></div>
            )}
            <span className={`text-xs font-semibold ${colors.statusText} uppercase tracking-wide`}>
              {statusLabels[status]}
            </span>
          </div>
        </div>

        <h3 className="text-white font-semibold text-lg mb-2">{title}</h3>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">Last Scan:</span>
            <span className="text-gray-300 text-sm font-medium">{lastScan}</span>
          </div>

          {itemsFound > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-gray-500 text-sm">Detected:</span>
              <span className={`${colors.statusText} text-sm font-bold`}>{itemsFound} items</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

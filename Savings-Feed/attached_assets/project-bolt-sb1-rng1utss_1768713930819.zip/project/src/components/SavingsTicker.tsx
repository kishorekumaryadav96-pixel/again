import { TrendingUp, DollarSign } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function SavingsTicker() {
  const [savings, setSavings] = useState(2847.32);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setSavings((prev) => prev + Math.random() * 0.5);
      setTimeout(() => setIsAnimating(false), 500);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gradient-to-br from-gray-950 via-gray-900 to-black border border-gray-800/50 rounded-2xl p-6 backdrop-blur-xl relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-cyan-500/5"></div>
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-500 opacity-50"></div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center border border-blue-500/20">
              <DollarSign className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-gray-400 text-sm font-medium uppercase tracking-wider">Total Savings Recovered</span>
          </div>
          <div className="flex items-center gap-1.5 bg-green-500/10 px-3 py-1.5 rounded-full border border-green-500/20">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-sm font-semibold">+12.4%</span>
          </div>
        </div>

        <div className="flex items-baseline gap-2">
          <span className={`text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent transition-all duration-500 ${
            isAnimating ? 'scale-105' : 'scale-100'
          }`}>
            ${savings.toFixed(2)}
          </span>
          <span className="text-gray-500 text-lg font-medium">USD</span>
        </div>

        <div className="mt-4 flex items-center gap-4 text-sm">
          <div>
            <span className="text-gray-500">This Month:</span>
            <span className="text-white font-semibold ml-2">$234.50</span>
          </div>
          <div className="w-1 h-4 bg-gray-800 rounded-full"></div>
          <div>
            <span className="text-gray-500">Active Scans:</span>
            <span className="text-blue-400 font-semibold ml-2">3</span>
          </div>
        </div>
      </div>
    </div>
  );
}

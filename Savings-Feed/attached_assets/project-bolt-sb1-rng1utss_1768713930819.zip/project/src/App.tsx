import { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import SubscriptionAssassin from './components/SubscriptionAssassin';

type View = 'dashboard' | 'subscription-assassin';

function App() {
  const [currentView] = useState<View>('subscription-assassin');

  return (
    <Layout>
      {currentView === 'dashboard' && <Dashboard />}
      {currentView === 'subscription-assassin' && (
        <div className="min-h-screen bg-black p-8">
          <div className="max-w-7xl mx-auto">
            <SubscriptionAssassin />
          </div>
        </div>
      )}
    </Layout>
  );
}

export default App;
